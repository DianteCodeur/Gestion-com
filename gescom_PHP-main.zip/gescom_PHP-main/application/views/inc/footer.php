
    	<script>
            var resizefunc = [];
        </script>

        <!-- Main  -->
        <script src="<?php echo js_url('jquery.min');?>"></script>
        <script src="<?php echo js_url('bootstrap.min');?>"></script>
        <script src="<?php echo js_url('detect');?>"></script>
        <script src="<?php echo js_url('fastclick');?>"></script>
        <script src="<?php echo js_url('jquery.slimscroll');?>"></script>
        <script src="<?php echo js_url('jquery.blockUI');?>"></script>
        <script src="<?php echo js_url('waves');?>"></script>
        <script src="<?php echo js_url('wow.min');?>"></script>
        <script src="<?php echo js_url('jquery.nicescroll');?>"></script>
        <script src="<?php echo js_url('jquery.scrollTo.min');?>"></script>


        <script src="<?php echo js_url('jquery.app');?>"></script>

<!-- Datatables-->
         <script src="<?php echo js_url_plugins();?>/datatables/jquery.dataTables.min.js"></script>
        <script src="<?php echo js_url_plugins();?>/datatables/dataTables.bootstrap.js"></script>
        <script src="<?php echo js_url_plugins();?>/datatables/dataTables.buttons.min.js"></script>
        <script src="<?php echo js_url_plugins();?>/datatables/buttons.bootstrap.min.js"></script>
        <script src="<?php echo js_url_plugins();?>/datatables/dataTables.responsive.min.js"></script>
        <script src="<?php echo js_url_plugins();?>/datatables/responsive.bootstrap.min.js"></script>
        <script src="<?php echo js_url_plugins();?>/datatables/dataTables.scroller.min.js"></script>
<!-- Select-->
<script src="<?php echo js_url_plugins();?>/select2/dist/js/select2.min.js" type="text/javascript"></script>

        <!-- Mon Script -->
        <script src="<?php echo js_url('myScript');?>"></script>
	</body>
</html>