<div class="">
    </br><img src="<?php echo img_url("big/bge.JPG")?>" alt="user-img" class="img-circle" style="margin-left:400px"></br>
    
    <h3 class="text-center m-t-10 text-white"><strong style="color:black; font-family:times new roman">Biblio-Gyptien <span style="font-size:16px; font-weight:bold">VOUS SOUHAITE LA BIENVENUE</span></strong> </h3>
</div>