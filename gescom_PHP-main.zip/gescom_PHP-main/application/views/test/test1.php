Bienvenue dans la vue Test1
Nous sommes des bleus en CodeIgniter