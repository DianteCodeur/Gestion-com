<?php  echo "Nom: ".$nom;?>
<br>
<?php  echo "Prenom: ".$prenom;?>
<?php
print_r($lesnoms);

?>